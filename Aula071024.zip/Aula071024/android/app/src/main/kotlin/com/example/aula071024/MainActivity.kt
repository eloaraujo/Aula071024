package com.example.aula071024

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
